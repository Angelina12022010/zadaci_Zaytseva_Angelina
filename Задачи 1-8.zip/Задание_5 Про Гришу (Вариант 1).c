#include <stdio.h>

int main() {
	int time_f, time_sadacha, chas1 = 60, f, res;
	time_f = 5 * 60;	//время всего в мин
	time_sadacha = 45;	//время на одну задачу после f
	scanf("%d", &f);
	res = 12 - f;	//сколько задач нужно успеть сделать
	if (chas1 + res * time_sadacha <= time_f) {
		printf("YES");
	}
	else {printf("NO");}
	return 0;
}
