#include <stdio.h>

int formula (int n, int m) {
	return n * (m + 1);
}

int main () {
	int N, M, res;
	scanf("%d %d", &N, &M);
	
	res = formula(N, M);
	printf("%d", res);
	return 0;
}
