#include <stdio.h>

int schet (int g, int l) {
	int all = (g + l) - 1;
	int ne_g, ne_l;
	ne_g = all - g;
	ne_l = all - l;
	printf("%d %d", ne_g, ne_l);
	return 0;
}

int main () {
	int G, L, ne_G, ne_L;
	scanf("%d %d", &G, &L);
	schet(G, L);
	return 0;
}
