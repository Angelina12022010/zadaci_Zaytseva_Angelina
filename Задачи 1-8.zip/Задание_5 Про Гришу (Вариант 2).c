#include <stdio.h>

int yes_no (int f) {
	if (60 + (12 - f) * 45 <= 300) {
		printf("YES");
	}
	else {printf("NO");}
	return 0;
}

int main() {
	int f;
	scanf("%d", &f);
	yes_no (f);
	return 0;
}
