#include <stdio.h>

int proverca (int n1, int n2) {
	if ((n1 == 0 || n1 % 2 == 0)||(n2 % 2 != 0)) {
		printf("yes");
	}
	else printf("no");
	return 0;
}

int main () {
	int cod_1, cod_2, n_1, n_2;
	scanf("%4d\n%4d", &cod_1, &cod_2);
	n_1 = cod_1 % 10;
	n_2 = cod_2 % 10;
	proverca(n_1, n_2);
	return 0;
}
