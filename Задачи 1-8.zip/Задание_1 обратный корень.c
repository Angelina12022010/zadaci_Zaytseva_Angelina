#include <stdio.h>
#include <math.h>
#define MAXN 100

double obrat_cor(long long a) {
	
	return sqrt((double)a);	
}

int main () {
	long long ar[MAXN];
	int i;
	long long a;
	i = 0;
	while (scanf("%lld ", &a) == 1) {
		ar[i] = a;
		i = i + 1;
	}
	
	int count;
	for (count = i - 1; count >= 0; count = count - 1) {
		double res = obrat_cor(ar[count]);
		printf("%.4f\n", res);
	}
	return 0;
}
