#include<stdio.h>

int plus(int a, int b) {
	return a + b;
}

int main() {
	int a, b, sum;
	scanf("%d %d", &a, &b);
	sum = plus(a, b);
	printf("%d", sum);
	return 0;
}
