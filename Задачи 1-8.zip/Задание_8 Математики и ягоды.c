#include <stdio.h>
int main () {
	int m_1, m_2;
	int a_1, b_1;
	scanf("%d %d\n", &a_1, &b_1);
	int a_2, b_2;
	scanf("%d %d\n", &a_2, &b_2);
	int a_3, b_3;
	scanf("%d %d", &a_3, &b_3);
	
	m_1 = a_1 - a_3;
	m_2 = b_1 - b_2;
	printf("%d %d", m_1, m_2);
	return 0;
}
