#include <stdio.h>

int count_nanogram (int a, int b, int n) {
	return(a * b * n * 2);
}

int main() {
	int A, B, N, res;
	scanf("%d %d %d", &A, &B, &N);
	res = count_nanogram(A, B, N);
	printf("%d", res);
	return 0;
}
